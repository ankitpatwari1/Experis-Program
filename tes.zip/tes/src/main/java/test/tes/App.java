package test.tes;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.lang3.RandomStringUtils;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws IOException {
		int n = Integer.parseInt(args[0]);
		File file = new File("file.txt");
		file.createNewFile();
		BufferedWriter br = new BufferedWriter(new FileWriter(file));

		StringBuilder s = new StringBuilder();
		for (int i = 1; i <= n; i++) {

			s.append(RandomStringUtils.randomAlphanumeric(100));
			s.append("\n");
			System.out.println(s.toString().getBytes().length);
			if (s.toString().getBytes().length == 9*1000*101) {
				br.write(s.toString());
				br.flush();
				s = new StringBuilder();
			}

		}
		br.write(s.toString());
		br.flush();
		br.close();
	}
}
